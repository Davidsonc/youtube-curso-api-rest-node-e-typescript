<?php 
	// ensure this file is being included by a parent file
	if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );
	$GLOBALS["users"]=array(
	array('admin','$2a$08$aakc2izkRTXnh4kYSELLGeDU6F7WLuTOB.Qy0OBERio1nnrqA179C','C:/xampp/htdocs','http://localhost','1','','7',1),
); 
?>